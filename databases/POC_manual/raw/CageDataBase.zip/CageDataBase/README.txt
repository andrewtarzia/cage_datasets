1.This database of discrete organic molecules was created by Marcin Miklitz

2.It posseses cages reported in the scientific literature up-to-date

3.If more than polymorph is available it will stand as A - for alpha B - for beta G - for gamma

4.Unchanged CIF file obtained from CCDC (or other source) will be named with CCDC
code name (6 letters)

5.Some structures were refined by myself for example: disordered atoms with occupancies
were deleted manually, or solvent/guest molecule were deleted 

6.The name of the cages are 3 -characters, first letter of the name of founder (C - Cooper, M - Mastalerz) second letter for "Cage"

7.Third character is the defining number of chronologicaly reported.

8.CIF file with the name corresponding for the entry codename for example CC1a.cif
will stand for CC1 alpha polymorph refined for further applications (point 5)
Registry of any refinement will be stored within TXT file in proper directory
